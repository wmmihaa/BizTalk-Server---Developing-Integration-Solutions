namespace Lab14B.InvoiceProcess {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://xsd2.EDIPLUS_Invoic_AL014_v2",@"EDIPLUS_Invoic_AL014_v2")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::EDI.Unb21), XPath = @"/*[local-name()='EDIPLUS_Invoic_AL014_v2' and namespace-uri()='http://xsd2.EDIPLUS_Invoic_AL014_v2']/*[local-name()='R010_HEAD_1' and namespace-uri()='']/*[local-name()='F010_EgetPostkasseNr' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::EDI.Unb31), XPath = @"/*[local-name()='EDIPLUS_Invoic_AL014_v2' and namespace-uri()='http://xsd2.EDIPLUS_Invoic_AL014_v2']/*[local-name()='R010_HEAD_1' and namespace-uri()='']/*[local-name()='F030_ExternPostkasseNr' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"EDIPLUS_Invoic_AL014_v2"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"EDI.PropertySchema", typeof(global::EDI.PropertySchema))]
    public sealed class EDIPLUS_Invoic_AL014_v2 : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://xsd2.EDIPLUS_Invoic_AL014_v2"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""http://schemas.microsoft.com/Edi/PropertySchema"" targetNamespace=""http://xsd2.EDIPLUS_Invoic_AL014_v2"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <schemaEditorExtension:schemaInfo namespaceAlias=""b"" extensionClass=""Microsoft.BizTalk.FlatFileExtension.FlatFileExtension"" standardName=""Flat File"" xmlns:schemaEditorExtension=""http://schemas.microsoft.com/BizTalk/2003/SchemaEditorExtensions"" />
      <b:schemaInfo standard=""Flat File"" codepage=""1252"" default_pad_char="" "" pad_char_type=""char"" count_positions_by_byte=""false"" parser_optimization=""speed"" lookahead_depth=""3"" suppress_empty_nodes=""false"" generate_empty_nodes=""true"" allow_early_termination=""false"" early_terminate_optional_fields=""false"" allow_message_breakup_of_infix_root=""false"" compile_parse_tables=""false"" root_reference=""EDIPLUS_Invoic_AL014_v2"" />
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""http://schemas.microsoft.com/Edi/PropertySchema"" location=""EDI.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""EDIPLUS_Invoic_AL014_v2"">
    <xs:annotation>
      <xs:appinfo>
        <b:recordInfo structure=""delimited"" child_delimiter_type=""hex"" child_delimiter=""0xD 0xA"" child_order=""infix"" sequence_number=""1"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
        <b:properties>
          <b:property name=""ns0:UNB2_1"" xpath=""/*[local-name()='EDIPLUS_Invoic_AL014_v2' and namespace-uri()='http://xsd2.EDIPLUS_Invoic_AL014_v2']/*[local-name()='R010_HEAD_1' and namespace-uri()='']/*[local-name()='F010_EgetPostkasseNr' and namespace-uri()='']"" />
          <b:property name=""ns0:UNB3_1"" xpath=""/*[local-name()='EDIPLUS_Invoic_AL014_v2' and namespace-uri()='http://xsd2.EDIPLUS_Invoic_AL014_v2']/*[local-name()='R010_HEAD_1' and namespace-uri()='']/*[local-name()='F030_ExternPostkasseNr' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:annotation>
          <xs:appinfo>
            <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
          </xs:appinfo>
        </xs:annotation>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R010_HEAD_1"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" sequence_number=""1"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""HEAD"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F010_EgetPostkasseNr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F020_KvalifikatorEgenPostkasse"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F030_ExternPostkasseNr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F040_KvalifikatorExtPostkasse"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F050_ForlangKvittering"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""1"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F060_aftaled"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F070_TestFlag"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""1"" sequence_number=""8"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F080_DokumentKode"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""9"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F090_Fakturanummer"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""10"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F100_FakturaDato"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""8"" sequence_number=""11"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F110_DokumentDato"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""8"" sequence_number=""12"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R010_HEAD_2"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" sequence_number=""2"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""HEAD"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F120_ReferenceON"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F130_ReferenceDatoON"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""8"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F140_ReferenceVN"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F150_ReferenceDatoVN"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""8"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F160_ReferenceABO"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F170_ReferenceDatoABO"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""8"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F180_IVEDINr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""17"" sequence_number=""8"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F190_IVEDINrKval"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""9"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F200_IVAdresse1"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""10"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F210_IVAdresse2"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""11"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F220_IVAdresse3"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""12"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F230_IVAdresse4"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""13"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F240_IVAdresse5"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""14"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F250_IVLand"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""15"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R010_HEAD_3"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" sequence_number=""3"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""HEAD"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F260_BYEDINr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""17"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F270_BYEDINrKval"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F280_BYAdresse1"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F290_BYAdresse2"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F300_BYAdresse3"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F310_BYAdresse4"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F320_BYAdresse5"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""8"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F330_BYLand"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""9"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R010_HEAD_4"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" sequence_number=""4"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""HEAD"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F340_DPEDINr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""17"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F350_DPEDINrKval"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F360_DPAdresse1"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F370_DPAdresse2"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F380_DPAdresse3"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F390_DPAdresse4"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F400_DPAdresse5"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""8"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F410_DPLand"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""9"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R010_HEAD_5"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" sequence_number=""5"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""HEAD"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F420_SUEDINr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""17"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F430_SUEDINrKval"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F440_SUMomsRegnr"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F450_SUSalgsMedarbejder"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F460_SUAdministrativMedarbejder"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F470_StandardMomsPct"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F480_ValutaKode"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""8"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F490_BetalingsBetingelseTypeKval"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""9"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F500_BetalingsTidType"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""10"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F510_BetalingsTidRelation"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""11"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F520_BetalingsPeriodeType"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""12"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F530_BetalingAntalPerioder"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""13"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F540_XALDato"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""8"" sequence_number=""14"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F550_XALTid"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""11"" sequence_number=""15"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F560_FraTilType01"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""16"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F570_FraTilKvalifikator01"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""17"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F580_FraTilType01"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""18"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F590_FraTilBelop01"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""19"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F600_FraTilType02"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""20"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F610_FraTilKvalifikator02"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""21"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F620_FraTilType02"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""22"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F630_FraTilBelop02"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""23"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R020_LINE_LOOP"">
          <xs:annotation>
            <xs:appinfo>
              <recordInfo structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""6"" child_delimiter_type=""hex"" child_order=""infix"" child_delimiter=""0x0D 0x0A"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""R020_LINE_1"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:recordInfo structure=""positional"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""1"" tag_name=""LINE"" />
                  </xs:appinfo>
                </xs:annotation>
                <xs:complexType>
                  <xs:sequence>
                    <xs:annotation>
                      <xs:appinfo>
                        <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                      </xs:appinfo>
                    </xs:annotation>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LINE_NR"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F010_LinieAntal"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""6"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F020_VareNummerEAN"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F030_VareNummerEANType"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F040_VareNummerPIA1"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F050_VareNummerPIA1Kval"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F060_VareNummerPIA2"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""35"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F070_VareNummerPIA2Kval"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""8"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F080_AntalFaktureret"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""9"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F090_LinieBelop"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""10"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F100_NettoBeloppAAA"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""11"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F110_NettoBeloppAAABasis"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""10"" sequence_number=""12"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F120_NettoBeloppAAB"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""13"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F130_NettoBeloppAABBasis"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""10"" sequence_number=""14"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F140_FraTilKval"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""3"" sequence_number=""15"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F150_FraTilBeloppSamlet"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""16"" pad_char_type=""char"" pad_char="" "" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element minOccurs=""1"" maxOccurs=""1"" name=""R030_TOTAL"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" sequence_number=""7"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""TOTAL"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""5"" sequence_number=""1"" pad_char_type=""default"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F010_LinieAntal"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""6"" sequence_number=""2"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F020_VareLinieBelob"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""3"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F030_BruttoBelob"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""4"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F040_SkatteAfgiftsPligtigt"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""5"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F050_AfgiftBelobIalt"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""6"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element minOccurs=""1"" maxOccurs=""1"" name=""F060_SumFradragTillag"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" pos_offset=""0"" pos_length=""13"" sequence_number=""7"" pad_char_type=""char"" pad_char="" "" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        private const global::EDI.PropertySchema  __DummyVar0 = null;
        
        public EDIPLUS_Invoic_AL014_v2() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "EDIPLUS_Invoic_AL014_v2";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
