namespace Lab14B.InvoiceProcess {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Lab14B.InvoiceProcess.EDIPLUS_Invoic_AL014_v2", typeof(global::Lab14B.InvoiceProcess.EDIPLUS_Invoic_AL014_v2))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Lab14B.InvoiceProcess.EFACT_D93A_INVOIC", typeof(global::Lab14B.InvoiceProcess.EFACT_D93A_INVOIC))]
    public sealed class EDIPLUSINCOIC_to_D93AINVOIC2 : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:s0=""http://xsd2.EDIPLUS_Invoic_AL014_v2"" xmlns:ns0=""http://schemas.microsoft.com/BizTalk/EDI/EDIFACT/2006"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:EDIPLUS_Invoic_AL014_v2"" />
  </xsl:template>
  <xsl:template match=""/s0:EDIPLUS_Invoic_AL014_v2"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(&quot;DVA001V02&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(&quot;9&quot;)"" />
    <xsl:variable name=""var:v3"" select=""'3'"" />
    <xsl:variable name=""var:v4"" select=""R010_HEAD_1/F100_FakturaDato"" />
    <xsl:variable name=""var:v5"" select=""'102'"" />
    <xsl:variable name=""var:v6"" select=""'137'"" />
    <xsl:variable name=""var:v7"" select=""R010_HEAD_1/F110_DokumentDato"" />
    <xsl:variable name=""var:v8"" select=""'ON'"" />
    <xsl:variable name=""var:v9"" select=""R010_HEAD_2/F120_ReferenceON"" />
    <xsl:variable name=""var:v10"" select=""R010_HEAD_2/F130_ReferenceDatoON"" />
    <xsl:variable name=""var:v11"" select=""userCSharp:LogicalIsString(string($var:v10))"" />
    <xsl:variable name=""var:v13"" select=""'VN'"" />
    <xsl:variable name=""var:v14"" select=""R010_HEAD_2/F140_ReferenceVN"" />
    <xsl:variable name=""var:v15"" select=""R010_HEAD_2/F150_ReferenceDatoVN"" />
    <xsl:variable name=""var:v16"" select=""userCSharp:LogicalIsString(string($var:v15))"" />
    <xsl:variable name=""var:v18"" select=""'ABO'"" />
    <xsl:variable name=""var:v19"" select=""R010_HEAD_2/F160_ReferenceABO"" />
    <xsl:variable name=""var:v20"" select=""R010_HEAD_2/F170_ReferenceDatoABO"" />
    <xsl:variable name=""var:v21"" select=""userCSharp:LogicalIsString(string($var:v20))"" />
    <xsl:variable name=""var:v23"" select=""R010_HEAD_2/F180_IVEDINr"" />
    <xsl:variable name=""var:v24"" select=""userCSharp:LogicalIsString(string($var:v23))"" />
    <xsl:variable name=""var:v25"" select=""R010_HEAD_2/F200_IVAdresse1"" />
    <xsl:variable name=""var:v26"" select=""userCSharp:LogicalIsString(string($var:v25))"" />
    <xsl:variable name=""var:v27"" select=""userCSharp:LogicalOr(string($var:v24) , string($var:v26))"" />
    <xsl:variable name=""var:v34"" select=""R010_HEAD_3/F260_BYEDINr"" />
    <xsl:variable name=""var:v35"" select=""userCSharp:LogicalIsString(string($var:v34))"" />
    <xsl:variable name=""var:v36"" select=""R010_HEAD_3/F280_BYAdresse1"" />
    <xsl:variable name=""var:v37"" select=""userCSharp:LogicalIsString(string($var:v36))"" />
    <xsl:variable name=""var:v38"" select=""userCSharp:LogicalOr(string($var:v35) , string($var:v37))"" />
    <xsl:variable name=""var:v45"" select=""R010_HEAD_4/F340_DPEDINr"" />
    <xsl:variable name=""var:v46"" select=""userCSharp:LogicalIsString(string($var:v45))"" />
    <xsl:variable name=""var:v47"" select=""R010_HEAD_4/F360_DPAdresse1"" />
    <xsl:variable name=""var:v48"" select=""userCSharp:LogicalIsString(string($var:v47))"" />
    <xsl:variable name=""var:v49"" select=""userCSharp:LogicalOr(string($var:v46) , string($var:v48))"" />
    <xsl:variable name=""var:v56"" select=""userCSharp:LogicalExistence(boolean(R010_HEAD_5/F470_StandardMomsPct))"" />
    <xsl:variable name=""var:v58"" select=""boolean(R010_HEAD_5/F470_StandardMomsPct)"" />
    <xsl:variable name=""var:v59"" select=""userCSharp:LogicalExistence($var:v58)"" />
    <xsl:variable name=""var:v63"" select=""userCSharp:LogicalExistence(boolean(R010_HEAD_5/F480_ValutaKode))"" />
    <xsl:variable name=""var:v65"" select=""boolean(R010_HEAD_5/F480_ValutaKode)"" />
    <xsl:variable name=""var:v66"" select=""userCSharp:LogicalExistence($var:v65)"" />
    <xsl:variable name=""var:v69"" select=""userCSharp:LogicalExistence(boolean(R010_HEAD_5/F490_BetalingsBetingelseTypeKval))"" />
    <xsl:variable name=""var:v71"" select=""boolean(R010_HEAD_5/F490_BetalingsBetingelseTypeKval)"" />
    <xsl:variable name=""var:v72"" select=""userCSharp:LogicalExistence($var:v71)"" />
    <xsl:variable name=""var:v92"" select=""userCSharp:LogicalExistence(boolean(R030_TOTAL/F010_LinieAntal))"" />
    <xsl:variable name=""var:v94"" select=""boolean(R030_TOTAL/F010_LinieAntal)"" />
    <xsl:variable name=""var:v95"" select=""userCSharp:LogicalExistence($var:v94)"" />
    <xsl:variable name=""var:v98"" select=""'79'"" />
    <xsl:variable name=""var:v99"" select=""R030_TOTAL/F020_VareLinieBelob"" />
    <xsl:variable name=""var:v101"" select=""'86'"" />
    <xsl:variable name=""var:v102"" select=""R030_TOTAL/F030_BruttoBelob"" />
    <xsl:variable name=""var:v104"" select=""'125'"" />
    <xsl:variable name=""var:v105"" select=""R030_TOTAL/F040_SkatteAfgiftsPligtigt"" />
    <xsl:variable name=""var:v107"" select=""'176'"" />
    <xsl:variable name=""var:v108"" select=""R030_TOTAL/F050_AfgiftBelobIalt"" />
    <ns0:EFACT_D93A_INVOIC>
      <UNH>
        <UNH1>
          <xsl:text>0000277437</xsl:text>
        </UNH1>
        <UNH2>
          <UNH2.1>
            <xsl:text>INVOIC</xsl:text>
          </UNH2.1>
          <UNH2.2>
            <xsl:text>D</xsl:text>
          </UNH2.2>
          <UNH2.3>
            <xsl:text>93A</xsl:text>
          </UNH2.3>
          <UNH2.4>
            <xsl:text>UN</xsl:text>
          </UNH2.4>
          <UNH2.5>
            <xsl:text>EAN007</xsl:text>
          </UNH2.5>
        </UNH2>
      </UNH>
      <ns0:BGM>
        <ns0:C002>
          <C00201>
            <xsl:value-of select=""R010_HEAD_1/F080_DokumentKode/text()"" />
          </C00201>
          <C00204>
            <xsl:value-of select=""$var:v1"" />
          </C00204>
        </ns0:C002>
        <BGM02>
          <xsl:value-of select=""R010_HEAD_1/F090_Fakturanummer/text()"" />
        </BGM02>
        <BGM03>
          <xsl:value-of select=""$var:v2"" />
        </BGM03>
      </ns0:BGM>
      <ns0:DTM>
        <ns0:C507>
          <C50701>
            <xsl:value-of select=""$var:v3"" />
          </C50701>
          <C50702>
            <xsl:value-of select=""$var:v4"" />
          </C50702>
          <C50703>
            <xsl:value-of select=""$var:v5"" />
          </C50703>
        </ns0:C507>
      </ns0:DTM>
      <ns0:DTM>
        <ns0:C507>
          <C50701>
            <xsl:value-of select=""$var:v6"" />
          </C50701>
          <C50702>
            <xsl:value-of select=""$var:v7"" />
          </C50702>
          <C50703>
            <xsl:value-of select=""$var:v5"" />
          </C50703>
        </ns0:C507>
      </ns0:DTM>
      <ns0:RFFLoop1>
        <ns0:RFF>
          <ns0:C506>
            <C50601>
              <xsl:value-of select=""$var:v8"" />
            </C50601>
            <C50602>
              <xsl:value-of select=""$var:v9"" />
            </C50602>
          </ns0:C506>
        </ns0:RFF>
        <xsl:if test=""$var:v11"">
          <ns0:DTM_2>
            <ns0:C507_2>
              <xsl:if test=""string($var:v11)='true'"">
                <xsl:variable name=""var:v12"" select=""'171'"" />
                <C50701>
                  <xsl:value-of select=""$var:v12"" />
                </C50701>
              </xsl:if>
              <xsl:if test=""string($var:v11)='true'"">
                <C50702>
                  <xsl:value-of select=""$var:v10"" />
                </C50702>
              </xsl:if>
              <xsl:if test=""string($var:v11)='true'"">
                <C50703>
                  <xsl:value-of select=""$var:v5"" />
                </C50703>
              </xsl:if>
            </ns0:C507_2>
          </ns0:DTM_2>
        </xsl:if>
      </ns0:RFFLoop1>
      <ns0:RFFLoop1>
        <ns0:RFF>
          <ns0:C506>
            <C50601>
              <xsl:value-of select=""$var:v13"" />
            </C50601>
            <C50602>
              <xsl:value-of select=""$var:v14"" />
            </C50602>
          </ns0:C506>
        </ns0:RFF>
        <xsl:if test=""$var:v16"">
          <ns0:DTM_2>
            <ns0:C507_2>
              <xsl:if test=""string($var:v16)='true'"">
                <xsl:variable name=""var:v17"" select=""'171'"" />
                <C50701>
                  <xsl:value-of select=""$var:v17"" />
                </C50701>
              </xsl:if>
              <xsl:if test=""string($var:v16)='true'"">
                <C50702>
                  <xsl:value-of select=""$var:v15"" />
                </C50702>
              </xsl:if>
              <xsl:if test=""string($var:v16)='true'"">
                <C50703>
                  <xsl:value-of select=""$var:v5"" />
                </C50703>
              </xsl:if>
            </ns0:C507_2>
          </ns0:DTM_2>
        </xsl:if>
      </ns0:RFFLoop1>
      <ns0:RFFLoop1>
        <ns0:RFF>
          <ns0:C506>
            <C50601>
              <xsl:value-of select=""$var:v18"" />
            </C50601>
            <C50602>
              <xsl:value-of select=""$var:v19"" />
            </C50602>
          </ns0:C506>
        </ns0:RFF>
        <xsl:if test=""$var:v21"">
          <ns0:DTM_2>
            <ns0:C507_2>
              <xsl:if test=""string($var:v21)='true'"">
                <xsl:variable name=""var:v22"" select=""'171'"" />
                <C50701>
                  <xsl:value-of select=""$var:v22"" />
                </C50701>
              </xsl:if>
              <xsl:if test=""string($var:v21)='true'"">
                <C50702>
                  <xsl:value-of select=""$var:v20"" />
                </C50702>
              </xsl:if>
              <xsl:if test=""string($var:v21)='true'"">
                <C50703>
                  <xsl:value-of select=""$var:v5"" />
                </C50703>
              </xsl:if>
            </ns0:C507_2>
          </ns0:DTM_2>
        </xsl:if>
      </ns0:RFFLoop1>
      <ns0:NADLoop1>
        <ns0:NAD>
          <xsl:if test=""string($var:v27)='true'"">
            <xsl:variable name=""var:v28"" select=""'IV'"" />
            <NAD01>
              <xsl:value-of select=""$var:v28"" />
            </NAD01>
          </xsl:if>
          <ns0:C082>
            <xsl:if test=""string($var:v26)='true'"">
              <C08201>
                <xsl:value-of select=""$var:v23"" />
              </C08201>
            </xsl:if>
            <xsl:if test=""string($var:v26)='true'"">
              <xsl:variable name=""var:v29"" select=""R010_HEAD_2/F190_IVEDINrKval"" />
              <C08203>
                <xsl:value-of select=""$var:v29"" />
              </C08203>
            </xsl:if>
          </ns0:C082>
          <ns0:C058>
            <xsl:if test=""string($var:v26)='true'"">
              <C05801>
                <xsl:value-of select=""$var:v25"" />
              </C05801>
            </xsl:if>
            <xsl:if test=""string($var:v26)='true'"">
              <xsl:variable name=""var:v30"" select=""R010_HEAD_2/F210_IVAdresse2"" />
              <C05802>
                <xsl:value-of select=""$var:v30"" />
              </C05802>
            </xsl:if>
            <xsl:if test=""string($var:v26)='true'"">
              <xsl:variable name=""var:v31"" select=""R010_HEAD_2/F220_IVAdresse3"" />
              <C05803>
                <xsl:value-of select=""$var:v31"" />
              </C05803>
            </xsl:if>
            <xsl:if test=""string($var:v26)='true'"">
              <xsl:variable name=""var:v32"" select=""R010_HEAD_2/F240_IVAdresse5"" />
              <C05805>
                <xsl:value-of select=""$var:v32"" />
              </C05805>
            </xsl:if>
          </ns0:C058>
          <xsl:if test=""string($var:v26)='true'"">
            <xsl:variable name=""var:v33"" select=""R010_HEAD_2/F250_IVLand"" />
            <NAD09>
              <xsl:value-of select=""$var:v33"" />
            </NAD09>
          </xsl:if>
        </ns0:NAD>
      </ns0:NADLoop1>
      <ns0:NADLoop1>
        <ns0:NAD>
          <xsl:if test=""string($var:v38)='true'"">
            <xsl:variable name=""var:v39"" select=""'BY'"" />
            <NAD01>
              <xsl:value-of select=""$var:v39"" />
            </NAD01>
          </xsl:if>
          <ns0:C082>
            <xsl:if test=""string($var:v37)='true'"">
              <C08201>
                <xsl:value-of select=""$var:v34"" />
              </C08201>
            </xsl:if>
            <xsl:if test=""string($var:v37)='true'"">
              <xsl:variable name=""var:v40"" select=""R010_HEAD_3/F270_BYEDINrKval"" />
              <C08203>
                <xsl:value-of select=""$var:v40"" />
              </C08203>
            </xsl:if>
          </ns0:C082>
          <ns0:C058>
            <xsl:if test=""string($var:v37)='true'"">
              <C05801>
                <xsl:value-of select=""$var:v36"" />
              </C05801>
            </xsl:if>
            <xsl:if test=""string($var:v37)='true'"">
              <xsl:variable name=""var:v41"" select=""R010_HEAD_3/F290_BYAdresse2"" />
              <C05802>
                <xsl:value-of select=""$var:v41"" />
              </C05802>
            </xsl:if>
            <xsl:if test=""string($var:v37)='true'"">
              <xsl:variable name=""var:v42"" select=""R010_HEAD_3/F300_BYAdresse3"" />
              <C05803>
                <xsl:value-of select=""$var:v42"" />
              </C05803>
            </xsl:if>
            <xsl:if test=""string($var:v37)='true'"">
              <xsl:variable name=""var:v43"" select=""R010_HEAD_3/F320_BYAdresse5"" />
              <C05805>
                <xsl:value-of select=""$var:v43"" />
              </C05805>
            </xsl:if>
          </ns0:C058>
          <xsl:if test=""string($var:v37)='true'"">
            <xsl:variable name=""var:v44"" select=""R010_HEAD_3/F330_BYLand"" />
            <NAD09>
              <xsl:value-of select=""$var:v44"" />
            </NAD09>
          </xsl:if>
        </ns0:NAD>
      </ns0:NADLoop1>
      <ns0:NADLoop1>
        <ns0:NAD>
          <xsl:if test=""string($var:v49)='true'"">
            <xsl:variable name=""var:v50"" select=""'DP'"" />
            <NAD01>
              <xsl:value-of select=""$var:v50"" />
            </NAD01>
          </xsl:if>
          <ns0:C082>
            <xsl:if test=""string($var:v48)='true'"">
              <C08201>
                <xsl:value-of select=""$var:v45"" />
              </C08201>
            </xsl:if>
            <xsl:if test=""string($var:v48)='true'"">
              <xsl:variable name=""var:v51"" select=""R010_HEAD_4/F350_DPEDINrKval"" />
              <C08203>
                <xsl:value-of select=""$var:v51"" />
              </C08203>
            </xsl:if>
          </ns0:C082>
          <ns0:C058>
            <xsl:if test=""string($var:v48)='true'"">
              <C05801>
                <xsl:value-of select=""$var:v47"" />
              </C05801>
            </xsl:if>
            <xsl:if test=""string($var:v48)='true'"">
              <xsl:variable name=""var:v52"" select=""R010_HEAD_4/F370_DPAdresse2"" />
              <C05802>
                <xsl:value-of select=""$var:v52"" />
              </C05802>
            </xsl:if>
            <xsl:if test=""string($var:v48)='true'"">
              <xsl:variable name=""var:v53"" select=""R010_HEAD_4/F380_DPAdresse3"" />
              <C05803>
                <xsl:value-of select=""$var:v53"" />
              </C05803>
            </xsl:if>
            <xsl:if test=""string($var:v48)='true'"">
              <xsl:variable name=""var:v54"" select=""R010_HEAD_4/F400_DPAdresse5"" />
              <C05805>
                <xsl:value-of select=""$var:v54"" />
              </C05805>
            </xsl:if>
          </ns0:C058>
          <xsl:if test=""string($var:v48)='true'"">
            <xsl:variable name=""var:v55"" select=""R010_HEAD_4/F410_DPLand"" />
            <NAD09>
              <xsl:value-of select=""$var:v55"" />
            </NAD09>
          </xsl:if>
        </ns0:NAD>
      </ns0:NADLoop1>
      <ns0:TAXLoop1>
        <ns0:TAX>
          <xsl:if test=""string($var:v56)='true'"">
            <xsl:variable name=""var:v57"" select=""&quot;7&quot;"" />
            <TAX01>
              <xsl:value-of select=""$var:v57"" />
            </TAX01>
          </xsl:if>
          <ns0:C241>
            <xsl:if test=""string($var:v59)='true'"">
              <xsl:variable name=""var:v60"" select=""&quot;VAT&quot;"" />
              <C24101>
                <xsl:value-of select=""$var:v60"" />
              </C24101>
            </xsl:if>
          </ns0:C241>
          <ns0:C243>
            <xsl:if test=""string($var:v59)='true'"">
              <xsl:variable name=""var:v61"" select=""R010_HEAD_5/F470_StandardMomsPct/text()"" />
              <C24304>
                <xsl:value-of select=""$var:v61"" />
              </C24304>
            </xsl:if>
          </ns0:C243>
          <xsl:if test=""string($var:v59)='true'"">
            <xsl:variable name=""var:v62"" select=""&quot;S&quot;"" />
            <TAX06>
              <xsl:value-of select=""$var:v62"" />
            </TAX06>
          </xsl:if>
        </ns0:TAX>
      </ns0:TAXLoop1>
      <ns0:CUXLoop1>
        <ns0:CUX>
          <ns0:C504>
            <xsl:if test=""string($var:v63)='true'"">
              <xsl:variable name=""var:v64"" select=""&quot;2&quot;"" />
              <C50401>
                <xsl:value-of select=""$var:v64"" />
              </C50401>
            </xsl:if>
            <xsl:if test=""string($var:v66)='true'"">
              <xsl:variable name=""var:v67"" select=""R010_HEAD_5/F480_ValutaKode/text()"" />
              <C50402>
                <xsl:value-of select=""$var:v67"" />
              </C50402>
            </xsl:if>
            <xsl:if test=""string($var:v66)='true'"">
              <xsl:variable name=""var:v68"" select=""&quot;4&quot;"" />
              <C50403>
                <xsl:value-of select=""$var:v68"" />
              </C50403>
            </xsl:if>
          </ns0:C504>
        </ns0:CUX>
      </ns0:CUXLoop1>
      <ns0:PATLoop1>
        <ns0:PAT>
          <xsl:if test=""string($var:v69)='true'"">
            <xsl:variable name=""var:v70"" select=""R010_HEAD_5/F490_BetalingsBetingelseTypeKval/text()"" />
            <PAT01>
              <xsl:value-of select=""$var:v70"" />
            </PAT01>
          </xsl:if>
          <ns0:C112>
            <xsl:if test=""string($var:v72)='true'"">
              <xsl:variable name=""var:v73"" select=""R010_HEAD_5/F500_BetalingsTidType/text()"" />
              <C11201>
                <xsl:value-of select=""$var:v73"" />
              </C11201>
            </xsl:if>
            <xsl:if test=""string($var:v72)='true'"">
              <xsl:variable name=""var:v74"" select=""R010_HEAD_5/F510_BetalingsTidRelation/text()"" />
              <C11202>
                <xsl:value-of select=""$var:v74"" />
              </C11202>
            </xsl:if>
            <xsl:if test=""string($var:v72)='true'"">
              <xsl:variable name=""var:v75"" select=""R010_HEAD_5/F520_BetalingsPeriodeType/text()"" />
              <C11203>
                <xsl:value-of select=""$var:v75"" />
              </C11203>
            </xsl:if>
            <xsl:if test=""string($var:v72)='true'"">
              <xsl:variable name=""var:v76"" select=""R010_HEAD_5/F530_BetalingAntalPerioder/text()"" />
              <xsl:variable name=""var:v77"" select=""userCSharp:StringTrimLeft(string($var:v76))"" />
              <C11204>
                <xsl:value-of select=""$var:v77"" />
              </C11204>
            </xsl:if>
          </ns0:C112>
        </ns0:PAT>
      </ns0:PATLoop1>
      <xsl:for-each select=""R020_LINE_LOOP/R020_LINE_1"">
        <xsl:variable name=""var:v78"" select=""userCSharp:StringTrimLeft(string(F010_LinieAntal/text()))"" />
        <xsl:variable name=""var:v79"" select=""userCSharp:LogicalExistence(boolean(F040_VareNummerPIA1))"" />
        <xsl:variable name=""var:v81"" select=""boolean(F040_VareNummerPIA1)"" />
        <xsl:variable name=""var:v82"" select=""userCSharp:LogicalExistence($var:v81)"" />
        <xsl:variable name=""var:v84"" select=""userCSharp:LogicalExistence(boolean(F050_VareNummerPIA1Kval))"" />
        <xsl:variable name=""var:v86"" select=""userCSharp:LogicalExistence(boolean(F080_AntalFaktureret))"" />
        <xsl:variable name=""var:v88"" select=""boolean(F080_AntalFaktureret)"" />
        <xsl:variable name=""var:v89"" select=""userCSharp:LogicalExistence($var:v88)"" />
        <ns0:LINLoop1>
          <ns0:LIN>
            <LIN01>
              <xsl:value-of select=""$var:v78"" />
            </LIN01>
            <ns0:C212>
              <C21201>
                <xsl:value-of select=""F020_VareNummerEAN/text()"" />
              </C21201>
              <C21202>
                <xsl:value-of select=""F030_VareNummerEANType/text()"" />
              </C21202>
            </ns0:C212>
          </ns0:LIN>
          <ns0:PIA>
            <xsl:if test=""string($var:v79)='true'"">
              <xsl:variable name=""var:v80"" select=""&quot;1&quot;"" />
              <PIA01>
                <xsl:value-of select=""$var:v80"" />
              </PIA01>
            </xsl:if>
            <ns0:C212_2>
              <xsl:if test=""string($var:v82)='true'"">
                <xsl:variable name=""var:v83"" select=""F040_VareNummerPIA1/text()"" />
                <C21201>
                  <xsl:value-of select=""$var:v83"" />
                </C21201>
              </xsl:if>
              <xsl:if test=""string($var:v84)='true'"">
                <xsl:variable name=""var:v85"" select=""F050_VareNummerPIA1Kval/text()"" />
                <C21202>
                  <xsl:value-of select=""$var:v85"" />
                </C21202>
              </xsl:if>
            </ns0:C212_2>
          </ns0:PIA>
          <ns0:QTY_2>
            <ns0:C186_2>
              <xsl:if test=""string($var:v86)='true'"">
                <xsl:variable name=""var:v87"" select=""&quot;47&quot;"" />
                <C18601>
                  <xsl:value-of select=""$var:v87"" />
                </C18601>
              </xsl:if>
              <xsl:if test=""string($var:v89)='true'"">
                <xsl:variable name=""var:v90"" select=""F080_AntalFaktureret/text()"" />
                <xsl:variable name=""var:v91"" select=""userCSharp:StringTrimLeft(string($var:v90))"" />
                <C18602>
                  <xsl:value-of select=""$var:v91"" />
                </C18602>
              </xsl:if>
            </ns0:C186_2>
          </ns0:QTY_2>
        </ns0:LINLoop1>
      </xsl:for-each>
      <ns0:UNS>
        <UNS01>
          <xsl:text>S</xsl:text>
        </UNS01>
      </ns0:UNS>
      <ns0:CNT>
        <ns0:C270>
          <xsl:if test=""string($var:v92)='true'"">
            <xsl:variable name=""var:v93"" select=""&quot;2&quot;"" />
            <C27001>
              <xsl:value-of select=""$var:v93"" />
            </C27001>
          </xsl:if>
          <xsl:if test=""string($var:v95)='true'"">
            <xsl:variable name=""var:v96"" select=""R030_TOTAL/F010_LinieAntal/text()"" />
            <xsl:variable name=""var:v97"" select=""userCSharp:StringTrimLeft(string($var:v96))"" />
            <C27002>
              <xsl:value-of select=""$var:v97"" />
            </C27002>
          </xsl:if>
        </ns0:C270>
      </ns0:CNT>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v98"" />
            </C51601>
            <xsl:variable name=""var:v100"" select=""userCSharp:ConvertToNumber(string($var:v99))"" />
            <C51602>
              <xsl:value-of select=""$var:v100"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v101"" />
            </C51601>
            <xsl:variable name=""var:v103"" select=""userCSharp:ConvertToNumber(string($var:v102))"" />
            <C51602>
              <xsl:value-of select=""$var:v103"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v104"" />
            </C51601>
            <xsl:variable name=""var:v106"" select=""userCSharp:ConvertToNumber(string($var:v105))"" />
            <C51602>
              <xsl:value-of select=""$var:v106"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v107"" />
            </C51601>
            <xsl:variable name=""var:v109"" select=""userCSharp:ConvertToNumber(string($var:v108))"" />
            <C51602>
              <xsl:value-of select=""$var:v109"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
    </ns0:EFACT_D93A_INVOIC>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0)
{
   return param0;
}


public bool LogicalIsString(string val)
{
	return (val != null && val !="""");
}


public bool LogicalOr(string param0, string param1)
{
	return ValToBool(param0) || ValToBool(param1);
	return false;
}


public bool LogicalExistence(bool val)
{
	return val;
}


public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}


public decimal ConvertToNumber(string param1)
{
    return decimal.Parse(param1);
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool ValToBool(string val)
{
	if (val != null)
	{
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		val = val.Trim();
		if (string.Compare(val, bool.TrueString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return true;
		}
		if (string.Compare(val, bool.FalseString, StringComparison.OrdinalIgnoreCase) == 0)
		{
			return false;
		}
		double d = 0;
		if (IsNumeric(val, ref d))
		{
			return (d > 0);
		}
	}
	return false;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Lab14B.InvoiceProcess.EDIPLUS_Invoic_AL014_v2";
        
        private const string _strTrgSchemasList0 = @"Lab14B.InvoiceProcess.EFACT_D93A_INVOIC";
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Lab14B.InvoiceProcess.EDIPLUS_Invoic_AL014_v2";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Lab14B.InvoiceProcess.EFACT_D93A_INVOIC";
                return _TrgSchemas;
            }
        }
    }
}
